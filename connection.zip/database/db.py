import sqlite3


conn = sqlite3.connect('user_profile.db')
cur = conn.cursor()
