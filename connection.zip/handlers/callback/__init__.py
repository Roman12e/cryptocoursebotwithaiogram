from .maincallback import dp
from .othercallback import dp

__all__ = ["dp"]
